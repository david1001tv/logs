SET FOREIGN_KEY_CHECKS = 0;

--
-- Structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


--
-- Data for table `projects`
--

INSERT INTO `projects` (`id`, `name`) VALUES
 ('1', 'proj 1'),
 ('2', 'proj 2');


SET FOREIGN_KEY_CHECKS = 1;
